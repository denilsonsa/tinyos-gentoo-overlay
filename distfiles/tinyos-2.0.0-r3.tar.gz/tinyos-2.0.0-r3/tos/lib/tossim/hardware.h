#include <platform_hardware.h>
