$Id: README.txt,v 1.1.2.2.2.1 2006/11/07 00:45:55 scipio Exp $

README for Config
Author/Contact: tinyos-help@millennium.berkeley.edu

Description:

Application to demonstrate the ConfigStorageC abstraction.  A value is
written to, and read from, the flash storage.

A successful test will turn on both the green and blue (yellow)
LEDs.  A failed test is any other LED combination.

Tools:

Known bugs/limitations:

None.
