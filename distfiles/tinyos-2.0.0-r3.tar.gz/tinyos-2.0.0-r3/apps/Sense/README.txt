README for Sense 
Author/Contact: tinyos-help@millennium.berkeley.edu

Description:

Sense is a simple sensing demo application. It periodically samples the
default sensor and displays the bottom bits of the readings on the leds of the
node. Have a look at tinyos-2.x/doc/html/tutorial/lesson5.html for a general
tutorial on sensing in TinyOS.

Tools:

None.

Known bugs/limitations:

None.


$Id: README.txt,v 1.1.2.2 2006/06/23 14:07:13 janhauer Exp $
